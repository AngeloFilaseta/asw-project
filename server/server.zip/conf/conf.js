module.exports = {
    clientAddress: 'http://localhost:3001',
    dbAddress: 'mongodb://localhost:27017/guessr',
    token_secret: 'zawarudomudamudamudamuda',
    documentFolder: "./resources/pdf/",
    port: 3000,
    asciiArt: "   _____                     _____  \n" +
        "  / ____|                   |  __ \\ \n" +
        " | |  __ _   _  ___  ___ ___| |__) |\n" +
        " | | |_ | | | |/ _ \\/ __/ __|  _  / \n" +
        " | |__| | |_| |  __/\\__ \\__ \\ | \\ \\ \n" +
        "  \\_____|\\__,_|\\___||___/___/_|  \\_\\\n" +
        "                                    \n" +
        "                                     "
}